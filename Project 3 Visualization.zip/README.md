# Communicating Data Insight on Ford GoBike




## by Aluko Bamidele


## Dataset

This data set includes information about individual rides made in a bike-sharing system covering the greater San Francisco Bay area.

The Data Each trip is anonymized and includes:

Trip Duration 
Start Time and Date
End Time and Date
Start Station ID
Start Station Name
Start Station Latitude
Start Station Longitude
End Station ID
End Station Name
End Station Latitude
End Station Longitude
Bike ID
User Type (Subscriber or Customer – “Subscriber” = Member or “Customer” = Casual)

## Summary of Findings

 - In the exploration, it can be seen that subscribers mainly use the bike servies more during weekdays while the customers hire at the weekend. There is more tendency of the customers been recreational thatn the subscribers.
 - Most  Subscribers use the services at the peack hours

## Key Insights for Presentation

- Age has a significant effect on the distance covered. 
- There are more active activities during weekdays than on weekends. 
- Subscribers are actively using the services that the customers